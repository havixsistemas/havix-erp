import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Controller('products')
export class ProductsController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async list() {
    return this.prisma.product.findMany({ take: 50, orderBy: { createdAt: 'desc' } });
  }

  @Post()
  async create(@Body() body: any) {
    const { sku, name, salePrice = 0, costPrice = 0, companyId } = body;
    // fallback: create a default company if none provided
    let cmpId = companyId;
    if (!cmpId) {
      const company = await this.prisma.company.upsert({
        where: { tenantKey: 'tenant-dev' },
        create: { name: 'Havix Dev', tenantKey: 'tenant-dev' },
        update: {},
      });
      cmpId = company.id;
    }
    return this.prisma.product.create({
      data: { sku, name, salePrice: Number(salePrice||0), costPrice: Number(costPrice||0), companyId: cmpId },
    });
  }

  @Get(':id')
  async get(@Param('id') id: string) {
    return this.prisma.product.findUnique({ where: { id } });
  }
}