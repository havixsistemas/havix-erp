async function fetchProducts() {
  const base = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';
  const res = await fetch(base + '/products', { cache: 'no-store' });
  try { return await res.json(); } catch(e) { return []; }
}

export default async function Home() {
  const products = await fetchProducts();
  return (
    <main style={{fontFamily:'Inter, system-ui', padding: 24}}>
      <h1 style={{color:'#0B1F33'}}>Havix ERP — Demo</h1>
      <p>Produtos cadastrados (via API):</p>
      <ul>
        {Array.isArray(products) && products.map((p:any)=>(
          <li key={p.id}>{p.sku} — {p.name} — R$ {Number(p.salePrice||0).toFixed(2)}</li>
        ))}
      </ul>
    </main>
  );
}