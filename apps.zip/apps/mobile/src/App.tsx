import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as SQLite from 'expo-sqlite';
import axios from 'axios';

const db = SQLite.openDatabase('havix.db');

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#f6f7fb' },
  header: { padding: 16, backgroundColor: '#0B1F33' },
  headerText: { color: '#fff', fontWeight: '700', fontSize: 18 },
  card: { backgroundColor: '#fff', margin: 12, padding: 12, borderRadius: 12, shadowColor: '#0002', shadowOpacity: 0.1, shadowRadius: 6 },
  button: { backgroundColor: '#FF6600', padding: 10, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  buttonText: { color: '#fff', fontWeight: '700' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 8, marginVertical: 4 }
});

function initDb() {
  db.transaction(tx => {
    tx.executeSql('CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY NOT NULL, sku TEXT, name TEXT, price REAL);');
    tx.executeSql('CREATE TABLE IF NOT EXISTS queue (id INTEGER PRIMARY KEY AUTOINCREMENT, method TEXT, path TEXT, payload TEXT);');
  });
}

async function syncQueue() {
  return new Promise<void>((resolve) => {
    db.transaction(tx => {
      tx.executeSql('SELECT * FROM queue ORDER BY id ASC;', [], async (_, { rows }) => {
        for (let i = 0; i < rows.length; i++) {
          const item = rows.item(i);
          try {
            await axios({
              method: item.method,
              url: 'http://localhost:3001' + item.path,
              headers: { 'X-HAVIX-TENANT': 'tenant-dev' },
              data: JSON.parse(item.payload || '{}'),
            });
            db.transaction(tx2 => tx2.executeSql('DELETE FROM queue WHERE id = ?;', [item.id]));
          } catch (e) {
            // mantém na fila se falhar (offline)
            break;
          }
        }
        resolve();
      });
    });
  });
}

export default function App() {
  const [list, setList] = useState<any[]>([]);
  const [form, setForm] = useState({ sku: '', name: '', price: '' });

  useEffect(() => {
    initDb();
    loadLocal();
  }, []);

  async function loadLocal() {
    db.transaction(tx => {
      tx.executeSql('SELECT * FROM products;', [], (_, { rows }) => {
        const arr = [];
        for (let i = 0; i < rows.length; i++) arr.push(rows.item(i));
        setList(arr);
      });
    });
  }

  async function addProduct() {
    const id = Math.random().toString(36).slice(2);
    db.transaction(tx => {
      tx.executeSql('INSERT INTO products (id, sku, name, price) VALUES (?, ?, ?, ?);', [id, form.sku, form.name, Number(form.price || 0)]);
      tx.executeSql('INSERT INTO queue (method, path, payload) VALUES (?, ?, ?);', [
        'post', '/products', JSON.stringify({ sku: form.sku, name: form.name, salePrice: Number(form.price || 0), costPrice: 0 })
      ]);
    }, undefined, async () => {
      setForm({ sku: '', name: '', price: '' });
      await syncQueue();
      await loadLocal();
    });
  }

  return (
    <SafeAreaView style={styles.page}>
      <StatusBar style="light" />
      <View style={styles.header}><Text style={styles.headerText}>Havix ERP — Mobile</Text></View>
      <View style={styles.card}>
        <Text style={{ fontWeight: '700', color: '#0B1F33' }}>Cadastrar Produto (offline-first)</Text>
        <TextInput placeholder="SKU" style={styles.input} value={form.sku} onChangeText={(t)=>setForm({...form, sku: t})} />
        <TextInput placeholder="Nome" style={styles.input} value={form.name} onChangeText={(t)=>setForm({...form, name: t})} />
        <TextInput placeholder="Preço" keyboardType="decimal-pad" style={styles.input} value={form.price} onChangeText={(t)=>setForm({...form, price: t})} />
        <TouchableOpacity onPress={addProduct} style={styles.button}><Text style={styles.buttonText}>Salvar</Text></TouchableOpacity>
      </View>

      <View style={styles.card}>
        <Text style={{ fontWeight: '700', marginBottom: 6, color: '#0B1F33' }}>Produtos locais</Text>
        <FlatList data={list} keyExtractor={(i)=>i.id} renderItem={({item}) => (
          <View style={{ paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#eee' }}>
            <Text style={{ fontWeight: '600' }}>{item.name}</Text>
            <Text style={{ color: '#6b7280' }}>{item.sku} — R$ {item.price?.toFixed?.(2)}</Text>
          </View>
        )}/>
      </View>
    </SafeAreaView>
  );
}
